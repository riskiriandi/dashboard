# Dashboard BOT.MR.G

Dashboard web modern & simpel untuk mengontrol BOT.MR.G.

## Struktur
- `index.html` — Halaman utama
- `style.css` — Styling modern
- `script.js` — Logic tombol & indikator
- Siap diintegrasikan dengan backend (tinggal ganti/isi logic di `script.js`)

## Cara pakai
1. Clone repo ini
2. Buka `index.html` di browser

## Kustomisasi
- Untuk integrasi backend, tinggal modifikasi/isi fetch/ajax di `script.js`